let a = [];
        for (let i = 1; i <= Math.pow(10, 7); i++) {
            let b = Math.round(Math.random() * 1000) + 1;
            a.push(b);
        }
        console.time();
        mergeSort(a);
        console.timeEnd();

        function mergeSort(arr) {

            // 遞回函式終止條件：當陣列被拆到只剩一個元素時
            if (arr.length <= 1) {
                return arr
            }

            // 接受一組尚未排序的陣列當作參數，將它們對半切分
            let middleIndex = Math.floor(arr.length / 2)
            let firstHalf = arr.slice(0, middleIndex)
            let secondHalf = arr.slice(middleIndex)

            // 遞回
            return sortBeforeMerge(mergeSort(firstHalf), mergeSort(secondHalf))
        }

        function sortBeforeMerge(arr1, arr2) {
            /**
             * 代入兩個已經"各自排序過"的陣列，
             * 將這兩個陣列利用 merge sort 的方式排序後，合併回傳成一個陣列
             **/
            let sortedArr = []

            // 當 arr1 或 arr2 都不是空陣列時
            while (arr1.length && arr2.length) {
                // 以兩陣列中第一個元素進行比較，較小的推入 sortedArr 中
                let minElement = (arr1[0] < arr2[0]) ? arr1.shift() : arr2.shift()
                sortedArr.push(minElement)
            }

            /**
             * 會跳出上面 while 的迴圈，表示 arr1 或 arr2 其中至少有一個為空陣列
             * 因此，如果 arr1 不是空陣列，則把它 concat 到 sortedArr 內；
             * 如果是 arr2 中不是空陣列，則把它 concat 到 sortedArr 內。
             **/
            sortedArr = arr1.length ? sortedArr.concat(arr1) : sortedArr.concat(arr2)
            return sortedArr
        }